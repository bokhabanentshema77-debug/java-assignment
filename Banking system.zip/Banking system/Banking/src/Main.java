import banking.BankAccount;
import banking.SavingsAccount;
import banking.CurrentAccount;
import java.util.Scanner;
import java.io.FileWriter;
import java.time.LocalDateTime;
public  class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

    }
}

