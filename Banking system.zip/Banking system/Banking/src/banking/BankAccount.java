package banking;


import java.util.Scanner;
public abstract class BankAccount {
    private int Pin;
    private double balance;
    private String accountHolderName;
    private String accountNumber;

    public BankAccount(int Pin, double balance, String accountHolderName, String accountNumber)
            throws InvalidTransactionException {
        if(balance < 0) {
            throw new InvalidTransactionException("Balance cannot be negative");
        }
        this.Pin = Pin;
        this.balance = balance;
        this.accountHolderName = accountHolderName;
        this.accountNumber = accountNumber;
    }

    double getBalance(){
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    int getPin() {
        return Pin;
    }
    public void setPin(int Pin) {
        this.Pin = Pin;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }
    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }
    public String getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
    public abstract void deposit(double amount) throws InvalidTransactionException;
    public abstract void withdraw (double amount)  throws InvalidTransactionException;
    public abstract void CalculateInterest();

    public void transmit(BankAccount goal, double amount) throws InvalidTransactionException{
        this.withdraw(amount);
        goal.deposit(amount);

    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Pin : ");
        int pin = input.nextInt();
        System.out.print("Enter Balance : ");
        double balance = input.nextDouble();

    }
}


