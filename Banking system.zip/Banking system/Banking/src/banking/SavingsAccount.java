package banking;

public class SavingsAccount extends BankAccount{
    public SavingsAccount(int pin, double balance, String accountHolderName, String accountNumber){
        super(pin, balance, accountHolderName, accountNumber);
    }
    @Override
    public void deposit(double amount) throws InvalidTransactionException {

    }
    @Override
    public void withdraw(double amount) throws InvalidTransactionException {
        if(amount > getBalance()){
            throw new InvalidTransactionException("Insufficient Balance");
        }
    }
    @Override
    public void CalculateInterest() {

    }
}
